<?php
/**
 * Right Sidebar starter content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

return array(
	'search',
    'categories',
	'archives',
	'meta'
);
